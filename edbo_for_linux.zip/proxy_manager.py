# proxy_manager.py
import threading
from loguru import logger


class ProxyManager:
    def __init__(self, filepath):
        self.lock = threading.Lock()
        self.raw_list = []
        self.proxies = []
        self._idx = 0          # счётчик для round-robin
        self._load(filepath)

    def _load(self, filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    self.raw_list.append(line)
                    self.proxies.append(self._format(line))
            logger.info(f"Загружено прокси: {len(self.proxies)}")
        except FileNotFoundError:
            logger.warning("Файл прокси не найден")

    def _format(self, raw):
        """
        Приводит строку к http://user:pass@ip:port.
        Работает с:
          - user:pass@ip:port
          - ip:port
          - http://user:pass@ip:port (уже с схемой)
          - http://ip:port (уже с схемой)
        """
        raw = raw.strip()

        # Если уже со схемой — оставляем как есть
        if raw.startswith("http://") or raw.startswith("https://"):
            return raw

        # Авторизация присутствует
        if "@" in raw:
            auth, host = raw.split("@", 1)
            if ":" in auth:
                user, pwd = auth.split(":", 1)
                return f"http://{user}:{pwd}@{host}"
            # без пароля
            return f"http://{auth}@{host}"

        # Просто ip:port
        return f"http://{raw}"

    def get(self):
        """
        Round-robin: каждый вызов возвращает следующий прокси.
        Потокобезопасно, без коллизий между воркерами.
        """
        with self.lock:
            if not self.proxies:
                return None
            proxy = self.proxies[self._idx % len(self.proxies)]
            self._idx += 1
            return proxy

    def remove(self, proxy_url):
        with self.lock:
            if proxy_url in self.proxies:
                self.proxies.remove(proxy_url)
                # сбрасываем счётчик, чтобы не выйти за границы
                self._idx = 0
                logger.warning(f"Прокси удалён. Осталось: {len(self.proxies)}")

    def count(self):
        with self.lock:
            return len(self.proxies)

    def all(self):
        """Возвращает копию списка всех прокси."""
        with self.lock:
            return list(self.proxies)