# launcher.py
"""
Точка входа для EXE.
- Обычный запуск: поднимает дашборд + открывает браузер.
- С флагом --run-scraper: запускает скрапер в этом же процессе.
"""
import os
import sys
import argparse
import threading
import time
import webbrowser
import traceback


def get_base_dir():
    """Корень проекта (работает и в EXE, и в обычном режиме)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def run_scraper(which, mode, source):
    """Запускает нужный скрапер в этом же процессе."""
    base = get_base_dir()
    os.chdir(base)

    # Гарантируем наличие папки results
    log_dir = os.path.join(base, "results")
    os.makedirs(log_dir, exist_ok=True)

    # Готовим argv так, как будто запущен per_person_v4.py
    sys.argv = ["per_person_v4.py", "--mode", mode, "--source", source]

    import asyncio

    try:
        if which == "per_person":
            from per_person_v4 import main as scraper_main
            # main(mode, source) — как в per_person_v4.py
            asyncio.run(scraper_main(mode, source))
        else:
            # scraper_async (если модуль существует)
            try:
                from scraper_async import main as scraper_main
                asyncio.run(scraper_main())
            except ImportError:
                err_path = os.path.join(log_dir, "launcher_scraper_error.log")
                with open(err_path, "a", encoding="utf-8") as f:
                    f.write("\n=== scraper_async модуль не найден ===\n")
                print("❌ Модуль scraper_async не найден. Используйте --which=per_person")
                sys.exit(2)
    except Exception:
        # Логируем ошибку в файл, чтобы её было видно в EXE
        err_path = os.path.join(log_dir, "launcher_scraper_error.log")
        with open(err_path, "a", encoding="utf-8") as f:
            f.write(f"\n=== {which} | mode={mode} | source={source} ===\n")
            traceback.print_exc(file=f)
        raise


def run_dashboard():
    """Flask дашборд + автооткрытие браузера."""
    base = get_base_dir()
    os.chdir(base)

    def open_browser():
        time.sleep(2)
        webbrowser.open("http://127.0.0.1:5000")

    threading.Thread(target=open_browser, daemon=True).start()

    from dashboard.app import create_app
    app = create_app()

    print("=" * 60)
    print("EDBO Scraper запущен")
    print("Открываю браузер: http://127.0.0.1:5000")
    print("Для остановки закройте это окно или нажмите Ctrl+C")
    print("=" * 60)

    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-scraper", action="store_true")
    parser.add_argument("--which", choices=["scraper", "per_person"],
                        default="per_person")
    parser.add_argument("--mode", choices=["anchor", "range"], default="range")
    parser.add_argument("--source", choices=["proxies", "direct"],
                        default="proxies")
    args, _ = parser.parse_known_args()

    if args.run_scraper:
        run_scraper(args.which, args.mode, args.source)
    else:
        run_dashboard()


if __name__ == "__main__":
    main()