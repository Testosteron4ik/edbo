# per_person_v4.py
"""
Per-Person Search v4 — финальная версия (aiohttp).
Перебирает номера довідок для каждого ІПН.
Логи сохраняются в CSV.

Особенности:
- Одна общая ClientSession, прокси per-request (round-robin).
- Атомарное сохранение прогресса (tmp + fsync + replace).
- Параллельная обработка без "batch-простоя" (asyncio.wait + running set).
- Watermark-сохранение прогресса: позиция фиксируется только
  когда весь непрерывный префикс задач завершён.
- Exponential backoff для 500/503/429, смягчённый BACKOFF_508.
"""
import os
import sys
import csv
import json
import time
import random
import asyncio
import argparse
from datetime import datetime

import aiohttp
import aiofiles
from bs4 import BeautifulSoup
from loguru import logger

from config import (
    RESULTS_DIR, RESULTS_FILE, FOUND_FILE, PROXIES_FILE,
    BASE_URL, USER_AGENTS, BASE_HEADERS, REQUEST_TIMEOUT,
)
from proxy_manager import ProxyManager

# ═══════════════════════════════════════════════════
#  ФАЙЛЫ
# ═══════════════════════════════════════════════════
PROGRESS_FILE = os.path.join(RESULTS_DIR, "progress_v4.json")
SETTINGS_FILE = os.path.join(RESULTS_DIR, "settings.json")
LOGS_CSV = os.path.join(RESULTS_DIR, "logs.csv")
FINAL_REPORT_CSV = os.path.join(RESULTS_DIR, "final_report.csv")

# ═══════════════════════════════════════════════════
#  НАСТРОЙКИ ПО УМОЛЧАНИЮ
# ═══════════════════════════════════════════════════
_default_settings = {
    "day_start": 24000,
    "day_end": 37148,
    "seq_start": 1,
    "seq_end": 300,
    "num_start": 980000,
    "num_end": 981000,
    "max_requests_per_inn": 1000,
    "concurrency_proxy": 30,
    "concurrency_direct": 5,
    "request_delay_proxy": 0.2,
    "request_delay_direct": 0.5,
    "gender_filter": "male",
}

_cfg = _default_settings.copy()
if os.path.exists(SETTINGS_FILE):
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as _f:
            _cfg.update(json.load(_f))
    except Exception:
        pass

DAY_START = int(_cfg["day_start"])
DAY_END = int(_cfg["day_end"])
SEQ_START = int(_cfg["seq_start"])
SEQ_END = int(_cfg["seq_end"])

NUM_START = int(_cfg["num_start"])
NUM_END = int(_cfg["num_end"])
MAX_REQUESTS_PER_INN = int(_cfg["max_requests_per_inn"])

CONCURRENCY_PROXY = int(_cfg["concurrency_proxy"])
CONCURRENCY_DIRECT = int(_cfg["concurrency_direct"])
REQUEST_DELAY_PROXY = float(_cfg["request_delay_proxy"])
REQUEST_DELAY_DIRECT = float(_cfg["request_delay_direct"])

if _cfg["gender_filter"] == "male":
    GENDER_DIGITS = [1, 3, 5, 7, 9]
elif _cfg["gender_filter"] == "female":
    GENDER_DIGITS = [0, 2, 4, 6, 8]
else:
    GENDER_DIGITS = list(range(10))

# Anchor
ANCHOR_DAY = 35026
ANCHOR_INN = 3502605653
ANCHOR_NUM = 980146

# Retry / pause — смягчено для стабильности
RETRY_ATTEMPTS = 3
RETRY_DELAY = 3.0
BACKOFF_508 = 15.0         # было 60 — 15 достаточно, чтобы переждать всплеск
GLOBAL_PAUSE = 60.0        # было 180 — 3 минуты очень много
PAUSE_THRESHOLD = 15       # было 5 — слишком чувствительно

# ═══════════════════════════════════════════════════
#  ИНИЦИАЛИЗАЦИЯ
# ═══════════════════════════════════════════════════
os.makedirs(RESULTS_DIR, exist_ok=True)
logger.add(os.path.join(RESULTS_DIR, "per_person_v4.log"),
           rotation="20 MB", retention="7 days", level="INFO")

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

csv_lock = asyncio.Lock()
stats_lock = asyncio.Lock()
pause_lock = asyncio.Lock()
sessions_lock = asyncio.Lock()
log_lock = asyncio.Lock()
progress_lock = asyncio.Lock()

pause_state = {"is_paused": False}

sessions = {}
stats = {
    "checked_inn": 0, "found_inn": 0,
    "total_requests": 0, "errors": 0, "http_508": 0,
    "start_time": None, "consecutive_508": 0,
}

settings = {
    "source": "direct",
    "concurrency": CONCURRENCY_DIRECT,
    "request_delay": REQUEST_DELAY_DIRECT,
    "is_direct": True,
}


# ═══════════════════════════════════════════════════
#  ЛОГИ В CSV
# ═══════════════════════════════════════════════════

def log_event(event, inn=None, num=None, status="", details=""):
    try:
        file_exists = os.path.exists(LOGS_CSV)
        with open(LOGS_CSV, "a", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            if not file_exists:
                w.writerow(["timestamp", "event", "inn", "num", "status", "details"])
            w.writerow([
                datetime.now().isoformat(),
                event,
                inn if inn is not None else "",
                num if num is not None else "",
                status,
                str(details)[:500]
            ])
    except Exception:
        pass


async def log_event_async(event, inn=None, num=None, status="", details=""):
    try:
        async with log_lock:
            await asyncio.to_thread(log_event, event, inn, num, status, details)
    except Exception as e:
        logger.debug(f"Не удалось записать CSV-лог: {e}")


def save_final_report():
    try:
        elapsed = time.time() - (stats["start_time"] or time.time())
        with open(FINAL_REPORT_CSV, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["metric", "value"])
            w.writerow(["Дата отчёта", datetime.now().isoformat()])
            w.writerow(["Источник", settings["source"]])
            w.writerow(["Всего проверено ІПН", stats["checked_inn"]])
            w.writerow(["Найдено довідок", stats["found_inn"]])
            hr = (stats["found_inn"] / stats["checked_inn"] * 100) if stats["checked_inn"] else 0
            w.writerow(["Hit Rate %", round(hr, 3)])
            w.writerow(["Всего запросов", stats["total_requests"]])
            w.writerow(["Ошибок", stats["errors"]])
            w.writerow(["508 блокировок", stats["http_508"]])
            w.writerow(["Время работы (сек)", int(elapsed)])
    except Exception as e:
        logger.error(f"Не удалось сохранить отчёт: {e}")


# ═══════════════════════════════════════════════════
#  CONTROL DIGIT РНОКПП
# ═══════════════════════════════════════════════════

def calculate_control_digit(first_9):
    weights = [-1, 5, 7, 9, 4, 6, 10, 5, 7]
    total = sum(int(d) * w for d, w in zip(str(first_9), weights))
    return (total % 11) % 10


def generate_valid_inn(day, seq, gender):
    base = f"{day:05d}{seq:03d}{gender}"
    control = calculate_control_digit(base)
    return int(f"{base}{control}")


# ═══════════════════════════════════════════════════
#  CSV / PROGRESS
# ═══════════════════════════════════════════════════

def ensure_csv():
    for path in (RESULTS_FILE, FOUND_FILE):
        if not os.path.exists(path):
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                csv.writer(f, delimiter=";").writerow(
                    ["num", "inn", "status", "data", "timestamp"]
                )


async def save_row_async(num, inn, status, data):
    line = [num, inn, status, data, datetime.now().isoformat()]
    async with csv_lock:
        async with aiofiles.open(RESULTS_FILE, "a", newline="", encoding="utf-8-sig") as f:
            await f.write(";".join(str(x) for x in line) + "\n")
        if status == "found":
            async with aiofiles.open(FOUND_FILE, "a", newline="", encoding="utf-8-sig") as f:
                await f.write(";".join(str(x) for x in line) + "\n")


def load_progress():
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"mode": None, "day": DAY_START, "seq": SEQ_START,
            "gender_idx": 0, "checked_inn": 0, "found_inn": 0}


def save_progress(mode, day, seq, g_idx, checked, found):
    """Атомарно сохраняет прогресс, чтобы не оставить битый JSON при остановке."""
    payload = {
        "mode": mode,
        "day": int(day),
        "seq": int(seq),
        "gender_idx": int(g_idx),
        "checked_inn": int(checked),
        "found_inn": int(found),
        "saved_at": datetime.now().isoformat(),
    }
    tmp = PROGRESS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, PROGRESS_FILE)


async def save_progress_async(mode, day, seq, g_idx, checked, found):
    async with progress_lock:
        await asyncio.to_thread(
            save_progress, mode, day, seq, g_idx, checked, found
        )


# ═══════════════════════════════════════════════════
#  ПАРСИНГ
# ═══════════════════════════════════════════════════

def parse_html(html):
    soup = BeautifulSoup(html, "html.parser")
    rows = soup.find("div", class_="result-rows")
    if not rows:
        return "not_found", ""
    data = {}
    for row in rows.find_all("div", class_="result-row"):
        label = row.find("div", class_="result-label")
        value = row.find("div", class_="result-value")
        if label and value:
            data[label.get_text(strip=True)] = value.get_text(strip=True)
    return ("found", data) if data else ("not_found", "")


def build_headers():
    h = dict(BASE_HEADERS)
    h["User-Agent"] = random.choice(USER_AGENTS)
    h["Accept-Encoding"] = "gzip, deflate, br"
    h["Upgrade-Insecure-Requests"] = "1"
    h["Sec-Fetch-Dest"] = "document"
    h["Sec-Fetch-Mode"] = "navigate"
    h["Sec-Fetch-Site"] = "none"
    return h


# ═══════════════════════════════════════════════════
#  ПРОКСИ → URL ДЛЯ AIOHTTP
# ═══════════════════════════════════════════════════

def _normalize_proxy_url(proxy_url):
    """Приводит строку прокси к формату http://user:pass@ip:port."""
    if not proxy_url:
        return None
    if isinstance(proxy_url, dict):
        ip = proxy_url.get("ip")
        port = proxy_url.get("port")
        user = proxy_url.get("username") or proxy_url.get("user")
        pwd = proxy_url.get("password") or proxy_url.get("pass")
        if not ip or not port:
            return None
        if user and pwd:
            return f"http://{user}:{pwd}@{ip}:{port}"
        return f"http://{ip}:{port}"

    s = str(proxy_url).strip()
    if not s:
        return None
    if "://" not in s:
        s = f"http://{s}"
    return s


# ═══════════════════════════════════════════════════
#  СЕССИИ (aiohttp, одна общая, прокси per-request)
# ═══════════════════════════════════════════════════

async def init_sessions(proxies, is_direct):
    """
    Одна общая aiohttp.ClientSession. Прокси передаётся per-request в fetch().
    """
    async with sessions_lock:
        for s in sessions.values():
            try:
                await s.close()
            except Exception:
                pass
        sessions.clear()

        connector = aiohttp.TCPConnector(
            limit=200, limit_per_host=0,
            ttl_dns_cache=300, ssl=False,
            keepalive_timeout=60,
            enable_cleanup_closed=True,
        )
        sessions[None] = aiohttp.ClientSession(
            connector=connector,
            timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT),
        )

        if is_direct:
            logger.info("Режим DIRECT: 1 сессия без прокси")
        else:
            logger.info(
                f"Режим PROXY: 1 общая сессия, прокси применяется per-request "
                f"({proxies.count()} шт.)"
            )


async def close_all_sessions():
    async with sessions_lock:
        current = list(sessions.values())
        sessions.clear()
    for s in current:
        try:
            await s.close()
        except Exception as e:
            logger.debug(f"Ошибка закрытия aiohttp session: {e}")


# ═══════════════════════════════════════════════════
#  ГЛОБАЛЬНАЯ ПАУЗА
# ═══════════════════════════════════════════════════

async def trigger_global_pause(reason):
    async with pause_lock:
        if pause_state["is_paused"]:
            return
        pause_state["is_paused"] = True

    logger.warning(f"🚨 ГЛОБАЛЬНАЯ ПАУЗА {GLOBAL_PAUSE}с ({reason})")
    await log_event_async("global_pause", None, None, "pause", reason)
    try:
        await asyncio.sleep(GLOBAL_PAUSE)
    finally:
        async with stats_lock:
            stats["consecutive_508"] = 0
        async with pause_lock:
            pause_state["is_paused"] = False
        logger.info("▶️ Пауза завершена — продолжаем")
        await log_event_async("pause_end", None, None, "resume", "")


# ═══════════════════════════════════════════════════
#  ЗАПРОСЫ
# ═══════════════════════════════════════════════════

async def fetch(proxy_url, num, inn):
    session = sessions.get(None)
    if session is None:
        return "error", "no_session"

    url = f"{BASE_URL}?go=1&num={num}&inn={inn}"

    request_proxy = None
    if not settings["is_direct"]:
        request_proxy = _normalize_proxy_url(proxy_url)

    try:
        async with session.get(
            url,
            headers=build_headers(),
            proxy=request_proxy,   # ← прокси применяется здесь
        ) as resp:
            if resp.status == 508:
                return "error_508", "http_508"
            if resp.status == 500:
                return "error_500", "http_500"
            if resp.status == 503:
                return "error_503", "http_503"
            if resp.status == 429:
                return "error_429", "http_429"
            if resp.status != 200:
                return "error", f"http_{resp.status}"
            return parse_html(await resp.text())
    except asyncio.TimeoutError:
        return "error", "timeout"
    except aiohttp.ClientError as e:
        return "error", f"client_error: {type(e).__name__}: {e}"
    except Exception as e:
        return "error", f"{type(e).__name__}: {e}"


# ═══════════════════════════════════════════════════
#  ОБРАБОТКА ОДНОГО ІПН
# ═══════════════════════════════════════════════════

async def process_inn(inn, proxies, sem):
    """Проверяет один ІПН. MAX_REQUESTS_PER_INN — лимит HTTP-попыток."""
    requests_done = 0
    is_direct = settings["is_direct"]
    delay = settings["request_delay"]

    nums = list(range(NUM_START, NUM_END + 1))
    random.shuffle(nums)

    for num in nums:
        if requests_done >= MAX_REQUESTS_PER_INN:
            break

        while pause_state["is_paused"]:
            await asyncio.sleep(1)

        result_finished = False

        async with sem:
            for attempt in range(1, RETRY_ATTEMPTS + 1):
                if is_direct:
                    proxy_url = None
                else:
                    proxy_url = proxies.get()

                status, data = await fetch(proxy_url, num, inn)
                requests_done += 1

                async with stats_lock:
                    stats["total_requests"] += 1

                # ── 508 ──
                if status == "error_508":
                    async with stats_lock:
                        stats["http_508"] += 1
                        stats["consecutive_508"] += 1
                        c508 = stats["consecutive_508"]

                    await log_event_async(
                        "http_error", inn, num, "508",
                        f"attempt={attempt}/{RETRY_ATTEMPTS}"
                    )

                    # Если накопилось много подряд — глобальная пауза.
                    # После неё счётчик сбрасывается, и мы продолжаем
                    # со следующей попытки без дополнительного BACKOFF.
                    if c508 >= PAUSE_THRESHOLD:
                        await trigger_global_pause(f"{c508} подряд 508")
                        if attempt < RETRY_ATTEMPTS:
                            continue

                    if attempt < RETRY_ATTEMPTS:
                        await asyncio.sleep(BACKOFF_508)
                        continue

                    async with stats_lock:
                        stats["errors"] += 1
                    break

                # ── 500/503/429 ──
                if status in ("error_500", "error_503", "error_429"):
                    code = data.replace("http_", "")
                    await log_event_async(
                        "http_error", inn, num, code,
                        f"attempt={attempt}/{RETRY_ATTEMPTS}"
                    )

                    if attempt < RETRY_ATTEMPTS:
                        wait = min(30.0, RETRY_DELAY * (2 ** (attempt - 1)))
                        wait += random.uniform(0, 1.5)
                        await asyncio.sleep(wait)
                        continue

                    async with stats_lock:
                        stats["errors"] += 1
                    break

                # ── прочая ошибка ──
                if status == "error":
                    await log_event_async(
                        "request_error", inn, num, "error",
                        f"attempt={attempt}/{RETRY_ATTEMPTS}: {data}"
                    )

                    if attempt < RETRY_ATTEMPTS:
                        await asyncio.sleep(RETRY_DELAY * attempt)
                        continue

                    async with stats_lock:
                        stats["errors"] += 1
                    break

                # ── успешный HTTP-ответ ──
                async with stats_lock:
                    stats["consecutive_508"] = 0

                if status == "found":
                    data_str = " | ".join(
                        f"{k}={v}" for k, v in data.items()
                    )
                    await save_row_async(num, inn, "found", data_str)

                    pib = data.get("Прізвище, ім'я, по батькові", "?")
                    dob = data.get("Дата народження", "?")

                    logger.success(
                        f"✅ НАЙДЕНО: inn={inn} num={num} → {pib} ({dob})"
                    )
                    await log_event_async(
                        "found", inn, num, "found", f"{pib} ({dob})"
                    )

                    async with stats_lock:
                        stats["found_inn"] += 1

                    return True

                # not_found
                result_finished = True
                if delay > 0:
                    await asyncio.sleep(delay)
                break

        if result_finished:
            continue

    await save_row_async(None, inn, "no_dovidka", "")
    await log_event_async("no_dovidka", inn, None, "no_dovidka", "")
    return False


# ═══════════════════════════════════════════════════
#  ГЕНЕРАЦИЯ ЗАДАЧ
# ═══════════════════════════════════════════════════

def generate_anchor_tasks():
    tasks = []
    for seq_delta in range(-50, 51):
        seq = 56 + seq_delta
        if seq < 1 or seq > 999:
            continue
        inn = int(f"{ANCHOR_DAY:05d}{seq:03d}{5}")
        control = calculate_control_digit(inn)
        inn = int(f"{inn}{control}")
        tasks.append(inn)
    return tasks


def generate_range_tasks(progress):
    day = progress["day"]
    seq = progress["seq"]
    g_idx = progress["gender_idx"]

    while day <= DAY_END:
        while seq <= SEQ_END:
            while g_idx < len(GENDER_DIGITS):
                gender = GENDER_DIGITS[g_idx]
                inn = generate_valid_inn(day, seq, gender)
                yield (day, seq, g_idx, inn)
                g_idx += 1
            g_idx = 0
            seq += 1
        seq = SEQ_START
        day += 1


# ═══════════════════════════════════════════════════
#  HEARTBEAT
# ═══════════════════════════════════════════════════

async def heartbeat():
    try:
        while True:
            await asyncio.sleep(30)
            async with stats_lock:
                elapsed = time.time() - (stats["start_time"] or time.time())
                speed = (
                    stats["total_requests"] / elapsed
                    if elapsed > 0 else 0
                )
                checked = stats["checked_inn"]
                found = stats["found_inn"]
                errors = stats["errors"]
                requests = stats["total_requests"]
                http_508 = stats["http_508"]
                hr = (found / checked * 100) if checked else 0
                c508 = stats["consecutive_508"]
                paused = pause_state["is_paused"]

            state = "ПАУЗА" if paused else "работа"
            logger.info(
                f"💓 [{settings['source']}|{state}] "
                f"Проверено: {checked} | найдено: {found} ({hr:.2f}%) | "
                f"запросов: {requests} | ошибок: {errors} | "
                f"скорость: {speed:.2f} зап/сек | "
                f"508: {http_508} (подряд: {c508})"
            )
    except asyncio.CancelledError:
        logger.debug("Heartbeat остановлен")
        raise


# ═══════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════

async def main(mode, source):
    ensure_csv()
    proxies = ProxyManager(PROXIES_FILE)

    is_direct = (source == "direct")
    settings["source"] = source
    settings["is_direct"] = is_direct

    if is_direct:
        settings["concurrency"] = CONCURRENCY_DIRECT
        settings["request_delay"] = REQUEST_DELAY_DIRECT
        logger.warning(
            f"⚠️ Режим DIRECT: без прокси, "
            f"concurrency={settings['concurrency']}"
        )
    else:
        if proxies.count() == 0:
            logger.error("❌ Выбран proxy-режим, но proxies.txt пуст.")
            return
        settings["concurrency"] = CONCURRENCY_PROXY
        settings["request_delay"] = REQUEST_DELAY_PROXY
        logger.info(
            f"✅ Режим PROXY: {proxies.count()} прокси, "
            f"concurrency={settings['concurrency']}"
        )

    await init_sessions(proxies, is_direct)

    logger.info("═" * 60)
    logger.info(
        f"🎯 PER-PERSON v4 | Режим: {mode.upper()} | "
        f"Source: {source.upper()}"
    )
    logger.info(f"Concurrency: {settings['concurrency']}")
    logger.info(f"Request delay: {settings['request_delay']}с")
    logger.info(
        f"Диапазон номеров: {NUM_START}–{NUM_END} "
        f"({NUM_END - NUM_START + 1} шт.)"
    )
    logger.info(f"MAX_REQUESTS_PER_INN: {MAX_REQUESTS_PER_INN}")
    logger.info(f"Диапазон дней: {DAY_START}–{DAY_END}")
    logger.info(f"Seq: {SEQ_START}–{SEQ_END}")
    logger.info(f"GENDER_DIGITS: {GENDER_DIGITS}")
    logger.info(
        f"PAUSE_THRESHOLD: {PAUSE_THRESHOLD} | "
        f"GLOBAL_PAUSE: {GLOBAL_PAUSE}с | "
        f"BACKOFF_508: {BACKOFF_508}с"
    )
    logger.info("═" * 60)

    stats["start_time"] = time.time()
    sem = asyncio.Semaphore(settings["concurrency"])
    hb_task = asyncio.create_task(heartbeat())

    try:
        if mode == "anchor":
            tasks_list = generate_anchor_tasks()
            logger.info(f"Задач (anchor): {len(tasks_list)}")

            async def run_anchor(inn):
                try:
                    return await process_inn(inn, proxies, sem)
                finally:
                    async with stats_lock:
                        stats["checked_inn"] += 1
                        checked = stats["checked_inn"]
                        found = stats["found_inn"]
                    if checked % 10 == 0:
                        logger.info(
                            f"📌 Проверено {checked} | найдено {found}"
                        )

            await asyncio.gather(
                *(run_anchor(inn) for inn in tasks_list)
            )

        elif mode == "range":
            progress = load_progress()
            if progress.get("mode") != "range":
                progress = {
                    "mode": "range",
                    "day": DAY_START,
                    "seq": SEQ_START,
                    "gender_idx": 0,
                    "checked_inn": 0,
                    "found_inn": 0,
                }

            # Восстанавливаем только валидные значения.
            day = max(DAY_START, int(progress.get("day", DAY_START)))
            seq = max(SEQ_START, int(progress.get("seq", SEQ_START)))
            g_idx = max(0, int(progress.get("gender_idx", 0)))

            stats["checked_inn"] = int(progress.get("checked_inn", 0))
            stats["found_inn"] = int(progress.get("found_inn", 0))

            logger.info(
                f"Продолжаем с: day={day}, seq={seq}, gender_idx={g_idx}"
            )
            logger.info(
                f"Уже проверено: {stats['checked_inn']}, "
                f"найдено: {stats['found_inn']}"
            )

            inn_gen = generate_range_tasks({
                "day": day,
                "seq": seq,
                "gender_idx": g_idx,
            })

            # ── Параллельная обработка с watermark-прогрессом ──
            # running:      task -> index (порядковый номер задачи)
            # completed:    множество индексов завершённых, но ещё не
            #               прошедших через watermark
            # item_by_index: index -> (day, seq, g_idx, inn)
            # watermark:    следующий индекс, который ДОЛЖЕН быть завершён,
            #               чтобы можно было безопасно сохранить прогресс
            running = {}
            completed_idxs = set()
            item_by_index = {}
            state = {
                "next_index": 0,
                "watermark": 0,
                "last_saved_watermark": 0,
            }

            def submit_new():
                try:
                    item = next(inn_gen)
                except StopIteration:
                    return None
                idx = state["next_index"]
                state["next_index"] += 1
                item_by_index[idx] = item
                task = asyncio.create_task(process_inn(item[3], proxies, sem))
                running[task] = idx
                return task

            def advance_watermark():
                while state["watermark"] in completed_idxs:
                    completed_idxs.discard(state["watermark"])
                    state["watermark"] += 1

            async def save_watermark_progress():
                if state["watermark"] <= state["last_saved_watermark"]:
                    return
                last_idx = state["watermark"] - 1
                item = item_by_index.get(last_idx)
                if item is None:
                    return
                d, s, g, _ = item

                # Следующая позиция — сразу после последнего
                # непрерывно завершённого item.
                next_g = g + 1
                next_s = s
                next_d = d
                if next_g >= len(GENDER_DIGITS):
                    next_g = 0
                    next_s += 1
                if next_s > SEQ_END:
                    next_s = SEQ_START
                    next_d += 1

                async with stats_lock:
                    checked = stats["checked_inn"]
                    found = stats["found_inn"]

                await save_progress_async(
                    "range", next_d, next_s, next_g, checked, found
                )
                state["last_saved_watermark"] = state["watermark"]

                # Чистим уже ненужные items.
                for k in [k for k in item_by_index if k < state["watermark"]]:
                    del item_by_index[k]

            # Первичный запуск
            for _ in range(settings["concurrency"]):
                if submit_new() is None:
                    break

            while running:
                done, _ = await asyncio.wait(
                    list(running.keys()),
                    return_when=asyncio.FIRST_COMPLETED,
                )

                for task in done:
                    idx = running.pop(task, None)
                    if idx is None:
                        continue
                    completed_idxs.add(idx)

                    # Обрабатываем исключения задачи
                    exc = task.exception() if not task.cancelled() else None
                    if exc is not None:
                        logger.error(
                            f"Ошибка process_inn: "
                            f"{type(exc).__name__}: {exc}"
                        )
                        async with stats_lock:
                            stats["errors"] += 1

                    async with stats_lock:
                        stats["checked_inn"] += 1
                        checked_now = stats["checked_inn"]
                        found_now = stats["found_inn"]

                    if checked_now % 10 == 0:
                        logger.info(
                            f"📌 Проверено {checked_now} | "
                            f"найдено {found_now} | "
                            f"508: {stats['http_508']}"
                        )

                advance_watermark()
                await save_watermark_progress()

                # Подкидываем новые задачи — ровно столько, сколько освободилось.
                for _ in range(len(done)):
                    if submit_new() is None:
                        break

            # Финальное сохранение прогресса
            await save_watermark_progress()

        else:
            raise ValueError(f"Неизвестный mode: {mode}")

    except asyncio.CancelledError:
        logger.warning("Получена команда остановки.")
        raise
    except KeyboardInterrupt:
        logger.warning("Остановка пользователем.")
    except Exception as e:
        logger.exception(f"Критическая ошибка main(): {e}")
        raise
    finally:
        hb_task.cancel()
        try:
            await hb_task
        except asyncio.CancelledError:
            pass

        await close_all_sessions()

    elapsed = time.time() - (stats["start_time"] or time.time())

    async with stats_lock:
        checked = stats["checked_inn"]
        found = stats["found_inn"]
        requests = stats["total_requests"]
        errors = stats["errors"]
        http_508 = stats["http_508"]

    hr = (found / checked * 100) if checked else 0

    logger.success(
        f"🏁 Готово за {elapsed:.0f}с. "
        f"Проверено: {checked} | "
        f"Найдено: {found} ({hr:.2f}%) | "
        f"Запросов: {requests} | "
        f"Ошибок: {errors} | "
        f"508: {http_508}"
    )

    save_final_report()
    logger.info(f"Итоговый отчёт: {FINAL_REPORT_CSV}")
    logger.info(f"Логи событий: {LOGS_CSV}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["anchor", "range"], default="anchor")
    parser.add_argument("--source", choices=["proxies", "direct"], default="direct")
    args = parser.parse_args()
    asyncio.run(main(args.mode, args.source))