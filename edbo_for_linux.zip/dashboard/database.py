# dashboard/database.py
import os
import sqlite3
from datetime import datetime

DB_PATH = os.path.join("results", "dashboard.db")


def get_conn():
    os.makedirs("results", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()

    # Прокси
    cur.execute("""
        CREATE TABLE IF NOT EXISTS proxies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            address TEXT UNIQUE NOT NULL,
            status TEXT DEFAULT 'unknown',
            added_at TEXT,
            last_check TEXT,
            fail_count INTEGER DEFAULT 0
        )
    """)

    # База знаний (пары num + inn)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS knowledge (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            num INTEGER NOT NULL,
            inn INTEGER NOT NULL,
            source TEXT,
            added_at TEXT,
            UNIQUE(num, inn)
        )
    """)

    # Настройки (key-value)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    # История запусков скрапера
    cur.execute("""
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TEXT,
            stopped_at TEXT,
            mode TEXT,
            total_queries INTEGER DEFAULT 0,
            found INTEGER DEFAULT 0,
            status TEXT DEFAULT 'running',
            pid INTEGER
        )
    """)

    # Дефолтные настройки
    defaults = {
        "search_mode": "random",
        "concurrency": "30",
        "request_delay": "0.3",
        "batch_size_random": "2000",
        "focus_day": "35026",
        "gender_filter": "male",
        "only_odd_last": "1",
        "realistic_seq": "1",
        "range_num_start": "980000",
        "range_num_end": "981000",
        "range_day_start": "24000",
        "range_day_end": "37148",
    }
    for k, v in defaults.items():
        cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

    conn.commit()
    conn.close()


# ── Прокси ──
def add_proxy(address):
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO proxies (address, added_at) VALUES (?, ?)",
            (address.strip(), datetime.now().isoformat())
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()


def list_proxies():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM proxies ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_proxy(pid):
    conn = get_conn()
    conn.execute("DELETE FROM proxies WHERE id = ?", (pid,))
    conn.commit()
    conn.close()


# ── База знаний ──
def add_knowledge(num, inn, source=""):
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO knowledge (num, inn, source, added_at) VALUES (?, ?, ?, ?)",
            (num, inn, source, datetime.now().isoformat())
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()


def list_knowledge(limit=500):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM knowledge ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_knowledge(kid):
    conn = get_conn()
    conn.execute("DELETE FROM knowledge WHERE id = ?", (kid,))
    conn.commit()
    conn.close()


def count_knowledge():
    conn = get_conn()
    n = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
    conn.close()
    return n


# ── Настройки ──
def get_setting(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key, value):
    conn = get_conn()
    conn.execute(
        "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
        (key, str(value))
    )
    conn.commit()
    conn.close()


def all_settings():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM settings").fetchall()
    conn.close()
    return {r["key"]: r["value"] for r in rows}