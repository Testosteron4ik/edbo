# dashboard/app.py
import os
import sys
import csv
import json
import io
import zipfile
from datetime import datetime

from flask import Flask, render_template, request, jsonify, send_file

from dashboard.database import (
    init_db, add_proxy, list_proxies, delete_proxy, get_conn
)
from dashboard import scraper_controller as sc

app = Flask(__name__)

# ═══════════════════════════════════════════════════
#  АБСОЛЮТНЫЕ ПУТИ (работают и в EXE, и в обычном режиме)
# ═══════════════════════════════════════════════════
if getattr(sys, "frozen", False):
    # EXE: файлы рядом с exe (туда launcher делает os.chdir)
    BASE_DIR = os.path.dirname(sys.executable)
else:
    # Обычный режим: корень проекта
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RESULTS_DIR = os.path.join(BASE_DIR, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

SETTINGS_FILE = os.path.join(RESULTS_DIR, "settings.json")
PROGRESS_FILE = os.path.join(RESULTS_DIR, "progress_v4.json")

DEFAULT_SETTINGS = {
    "day_start": 24000,
    "day_end": 37148,
    "seq_start": 1,
    "seq_end": 300,
    "num_start": 980000,
    "num_end": 981000,
    "max_requests_per_inn": 1000,
    "concurrency_proxy": 30,
    "concurrency_direct": 5,
    "request_delay_proxy": 0.2,
    "request_delay_direct": 0.5,
    "gender_filter": "male",
}


def load_settings():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                merged = DEFAULT_SETTINGS.copy()
                merged.update(data)
                return merged
        except Exception:
            pass
    return DEFAULT_SETTINGS.copy()


def save_settings(data):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    if os.path.exists(PROGRESS_FILE):
        try:
            os.remove(PROGRESS_FILE)
        except Exception:
            pass


# ═══════════════════════════════════════════════════
#  ГЛАВНАЯ — поиск
# ═══════════════════════════════════════════════════

@app.route("/")
def index():
    status = sc.get_status()
    settings = load_settings()
    return render_template("per_person.html", status=status, settings=settings)


# ═══════════════════════════════════════════════════
#  УПРАВЛЕНИЕ
# ═══════════════════════════════════════════════════

@app.route("/api/status")
def api_status():
    return jsonify(sc.get_status())


@app.route("/api/start_per_person", methods=["POST"])
def api_start_per_person():
    data = request.json
    mode = data.get("mode", "range")
    source = data.get("source", "proxies")
    ok, msg = sc.start_per_person(mode, source)
    return jsonify({"ok": ok, "message": msg})


@app.route("/api/stop", methods=["POST"])
def api_stop():
    ok, msg = sc.stop_all()
    return jsonify({"ok": ok, "message": msg})


@app.route("/api/reset_progress", methods=["POST"])
def api_reset_progress():
    if os.path.exists(PROGRESS_FILE):
        try:
            os.remove(PROGRESS_FILE)
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)})
    return jsonify({"ok": True})


# ═══════════════════════════════════════════════════
#  НАСТРОЙКИ
# ═══════════════════════════════════════════════════

@app.route("/api/settings", methods=["GET", "POST"])
def api_settings():
    if request.method == "POST":
        data = request.json
        current = load_settings()
        for k, v in data.items():
            if k in current:
                default_val = DEFAULT_SETTINGS.get(k)
                if isinstance(default_val, int):
                    try:
                        current[k] = int(v)
                    except (ValueError, TypeError):
                        pass
                elif isinstance(default_val, float):
                    try:
                        current[k] = float(v)
                    except (ValueError, TypeError):
                        pass
                else:
                    current[k] = str(v)
        save_settings(current)
        return jsonify({"ok": True, "settings": current})
    return jsonify(load_settings())


# ═══════════════════════════════════════════════════
#  ПРОКСИ
# ═══════════════════════════════════════════════════

@app.route("/proxies")
def proxies_page():
    proxies = list_proxies()
    txt_count = 0
    proxies_txt = os.path.join(BASE_DIR, "proxies.txt")
    if os.path.exists(proxies_txt):
        with open(proxies_txt, "r", encoding="utf-8") as f:
            txt_count = sum(1 for line in f if line.strip())
    return render_template("proxies.html", proxies=proxies, txt_count=txt_count)


@app.route("/api/proxies", methods=["POST"])
def api_add_proxy():
    data = request.json
    addresses = data.get("addresses", "")
    added = 0
    for line in addresses.splitlines():
        line = line.strip()
        if line and add_proxy(line):
            added += 1
    return jsonify({"added": added})


@app.route("/api/proxies/<int:pid>", methods=["DELETE"])
def api_delete_proxy(pid):
    delete_proxy(pid)
    return jsonify({"ok": True})


@app.route("/api/proxies/clear", methods=["POST"])
def api_clear_proxies():
    conn = get_conn()
    conn.execute("DELETE FROM proxies")
    conn.commit()
    conn.close()
    proxies_txt = os.path.join(BASE_DIR, "proxies.txt")
    if os.path.exists(proxies_txt):
        open(proxies_txt, "w").close()
    return jsonify({"ok": True})


# ═══════════════════════════════════════════════════
#  ЛОГИ И НАЙДЕННЫЕ
# ═══════════════════════════════════════════════════

@app.route("/api/per_person_progress")
def api_per_person_progress():
    return jsonify(sc.get_per_person_progress())


@app.route("/api/per_person_logs")
def api_per_person_logs():
    """
    Читает лог скрапера. Пробует два файла:
      1) per_person_v4.log  — loguru-лог скрапера (основной в EXE)
      2) per_person_subprocess.log — stdout-перехват (для обычного режима)
    """
    candidates = [
        os.path.join(RESULTS_DIR, "per_person_v4.log"),
        os.path.join(RESULTS_DIR, "per_person_subprocess.log"),
    ]
    log_path = None
    for c in candidates:
        if os.path.exists(c) and os.path.getsize(c) > 0:
            log_path = c
            break

    if log_path is None:
        # Ни один не найден — вернём подсказку
        return jsonify({
            "lines": [
                "Лог ещё не создан.",
                f"Ожидаемые пути:",
                f"  {candidates[0]}",
                f"  {candidates[1]}",
                f"RESULTS_DIR = {RESULTS_DIR}",
            ]
        })

    n = int(request.args.get("n", 200))
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        return jsonify({"lines": [l.rstrip() for l in lines[-n:]]})
    except Exception as e:
        return jsonify({"lines": [f"Ошибка чтения {log_path}: {e}"]})


@app.route("/found")
def found_page():
    items = []
    found_path = os.path.join(RESULTS_DIR, "found.csv")
    if os.path.exists(found_path):
        with open(found_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f, delimiter=";")
            for row in reader:
                items.append(row)
    return render_template("found.html", items=items)


# ═══════════════════════════════════════════════════
#  СКАЧИВАНИЕ CSV
# ═══════════════════════════════════════════════════

@app.route("/download/<string:filename>")
def download_csv(filename):
    allowed = ["found.csv", "results.csv", "logs.csv", "final_report.csv", "stats.json"]
    if filename not in allowed:
        return jsonify({"ok": False, "error": "Файл не разрешён"}), 403

    path = os.path.join(RESULTS_DIR, filename)
    if not os.path.exists(path):
        return jsonify({"ok": False, "error": "Файл не найден"}), 404

    mimetype = "application/json" if filename.endswith(".json") else "text/csv"
    return send_file(
        path,
        as_attachment=True,
        download_name=filename,
        mimetype=mimetype
    )


@app.route("/download/all")
def download_all_zip():
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname in ("found.csv", "results.csv", "logs.csv", "final_report.csv", "stats.json"):
            fpath = os.path.join(RESULTS_DIR, fname)
            if os.path.exists(fpath):
                zf.write(fpath, arcname=fname)
    zip_buffer.seek(0)

    return send_file(
        zip_buffer,
        as_attachment=True,
        download_name=f"edbo_results_{datetime.now().strftime('%Y%m%d_%H%M')}.zip",
        mimetype="application/zip"
    )


# ═══════════════════════════════════════════════════

def create_app():
    init_db()
    return app


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=False)