# dashboard/scraper_controller.py
import os
import re
import sys
import json
import subprocess
from datetime import datetime

import psutil

# ── АБСОЛЮТНЫЕ ПУТИ (работают и в EXE, и в обычном режиме) ──
if getattr(sys, "frozen", False):
    # EXE: файлы рядом с exe (туда launcher делает os.chdir)
    BASE_DIR = os.path.dirname(sys.executable)
else:
    # Обычный режим: корень проекта
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RESULTS_DIR = os.path.join(BASE_DIR, "results")

SCRAPER_SCRIPT = "scraper_async.py"
PER_PERSON_SCRIPT = "per_person_v4.py"

SCRAPER_LOG = os.path.join(RESULTS_DIR, "subprocess.log")
PER_PERSON_LOG = os.path.join(RESULTS_DIR, "per_person_subprocess.log")
PROGRESS_FILE = os.path.join(RESULTS_DIR, "progress_v4.json")

# ── Маркеры для frozen-режима ──
RUN_SCRAPER_FLAG = "--run-scraper"
PER_PERSON_MARKER = "--which=per_person"

CURRENT_PROC = None
CURRENT_MODE = None


def _is_frozen():
    return getattr(sys, "frozen", False)


def _find_pids(kind):
    """
    kind: 'scraper' | 'per_person'
    Обычный режим: по имени скрипта в cmdline.
    Frozen (EXE): по --run-scraper + маркер --which=per_person.
    """
    pids = []
    my_pid = os.getpid()
    frozen = _is_frozen()

    for proc in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            if proc.pid == my_pid:
                continue

            cmdline = proc.info.get("cmdline") or []
            cmd_str = " ".join(str(x) for x in cmdline)

            if frozen:
                # В EXE — ищем только процессы с --run-scraper
                if RUN_SCRAPER_FLAG not in cmd_str:
                    continue
                is_per_person = PER_PERSON_MARKER in cmd_str

                if kind == "per_person" and is_per_person:
                    pids.append(proc.pid)
                elif kind == "scraper" and not is_per_person:
                    pids.append(proc.pid)
            else:
                # Обычный режим — по имени скрипта
                if kind == "per_person" and PER_PERSON_SCRIPT in cmd_str:
                    pids.append(proc.pid)
                elif kind == "scraper" and SCRAPER_SCRIPT in cmd_str:
                    pids.append(proc.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    return pids


def _kill_pids(pids):
    for pid in pids:
        try:
            p = psutil.Process(pid)
            p.terminate()
            try:
                p.wait(timeout=3)
            except psutil.TimeoutExpired:
                p.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass


def _kill_all():
    global CURRENT_PROC, CURRENT_MODE
    _kill_pids(_find_pids("scraper"))
    _kill_pids(_find_pids("per_person"))
    CURRENT_PROC = None
    CURRENT_MODE = None


def _start(script, log_path, args=None):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    log_file = open(log_path, "w", encoding="utf-8")
    log_file.write(f"=== ЗАПУСК {datetime.now().isoformat()} ===\n")
    log_file.flush()

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUNBUFFERED"] = "1"

    if _is_frozen():
        # В EXE — запускаем тот же exe с флагом
        cmd = [sys.executable, RUN_SCRAPER_FLAG]
        if script == PER_PERSON_SCRIPT:
            cmd.append(PER_PERSON_MARKER)  # --which=per_person
        if args:
            cmd.extend(args)
    else:
        # Обычный запуск — python script.py
        cmd = [sys.executable, os.path.join(BASE_DIR, script)]
        if args:
            cmd.extend(args)

    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0

    return subprocess.Popen(
        cmd,
        stdout=log_file,
        stderr=subprocess.STDOUT,
        env=env,
        cwd=BASE_DIR,
        creationflags=creationflags,
    )


def start_scraper(mode="random"):
    global CURRENT_PROC, CURRENT_MODE
    _kill_all()
    _update_search_mode_in_config(mode)
    CURRENT_PROC = _start(SCRAPER_SCRIPT, SCRAPER_LOG)
    CURRENT_MODE = f"scraper_{mode}"
    return True, f"Запущено (PID: {CURRENT_PROC.pid})"


def start_per_person(mode="anchor", source="direct"):
    """mode: 'anchor' | 'range'. source: 'proxies' | 'direct'."""
    global CURRENT_PROC, CURRENT_MODE
    _kill_all()
    CURRENT_PROC = _start(
        PER_PERSON_SCRIPT,
        PER_PERSON_LOG,
        args=["--mode", mode, "--source", source],
    )
    CURRENT_MODE = f"per_person_{mode}_{source}"
    return True, f"Per-Person [{mode}, {source}] запущен (PID: {CURRENT_PROC.pid})"


def stop_all():
    global CURRENT_PROC, CURRENT_MODE
    if not is_running():
        return False, "Ничего не запущено"
    _kill_all()
    return True, "Остановлено"


def is_running():
    return (
        len(_find_pids("scraper")) > 0
        or len(_find_pids("per_person")) > 0
    )


def get_status():
    per_person_pids = _find_pids("per_person")
    scraper_pids = _find_pids("scraper")

    per_person = len(per_person_pids) > 0
    scraper = len(scraper_pids) > 0

    pid = None
    if per_person:
        pid = per_person_pids[0]
    elif scraper:
        pid = scraper_pids[0]

    return {
        "running": per_person or scraper,
        "per_person_running": per_person,
        "scraper_running": scraper,
        "pid": pid,
        "mode": CURRENT_MODE,
    }


def get_per_person_progress():
    if not os.path.exists(PROGRESS_FILE):
        return {"checked_inn": 0, "found_inn": 0, "day": None, "seq": None}
    try:
        with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"checked_inn": 0, "found_inn": 0}


def _update_search_mode_in_config(mode):
    cfg = os.path.join(BASE_DIR, "config.py")
    if not os.path.exists(cfg):
        return
    with open(cfg, "r", encoding="utf-8") as f:
        content = f.read()
    content = re.sub(
        r'^SEARCH_MODE\s*=\s*"[^"]*"',
        f'SEARCH_MODE = "{mode}"',
        content,
        flags=re.MULTILINE,
    )
    with open(cfg, "w", encoding="utf-8") as f:
        f.write(content)