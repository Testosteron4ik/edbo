document.addEventListener('DOMContentLoaded', function () {
    const addBtn = document.getElementById('add-btn');
    if (addBtn) {
        addBtn.addEventListener('click', function () {
            const val = document.getElementById('proxy-input').value;
            if (!val.trim()) return;
            fetch('/api/proxies', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({addresses: val})
            })
                .then(r => r.json())
                .then(d => {
                    alert('Добавлено: ' + d.added);
                    location.reload();
                });
        });
    }

    document.querySelectorAll('.delete-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const id = btn.dataset.id;
            if (!confirm('Удалить прокси?')) return;
            fetch('/api/proxies/' + id, {method: 'DELETE'})
                .then(() => location.reload());
        });
    });
});