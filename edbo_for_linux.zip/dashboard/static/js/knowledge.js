document.addEventListener('DOMContentLoaded', function () {
    // Добавление пар
    const addBtn = document.getElementById('add-btn');
    if (addBtn) {
        addBtn.addEventListener('click', function () {
            const val = document.getElementById('kb-input').value;
            fetch('/api/knowledge', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({items: val})
            })
                .then(r => r.json())
                .then(d => {
                    alert('Добавлено: ' + d.added);
                    location.reload();
                });
        });
    }

    // Удаление пар
    document.querySelectorAll('.delete-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const id = btn.dataset.id;
            if (!confirm('Удалить пару?')) return;
            fetch('/api/knowledge/' + id, {method: 'DELETE'})
                .then(() => location.reload());
        });
    });
});