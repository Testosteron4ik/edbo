# config.py
import os
from datetime import datetime, timedelta

# ══════════════════════════════════════════════════════════
#  РЕЖИМ ПОИСКА
# ══════════════════════════════════════════════════════════
# "random" | "focus_day" | "seed_expansion" | "per_person"
SEARCH_MODE = "per_person"

# ══════════════════════════════════════════════════════════
#  БЕСКОНЕЧНЫЙ РЕЖИМ
# ══════════════════════════════════════════════════════════
RUN_FOREVER = True
BATCH_SIZE_RANDOM = 100000
LOOP_PAUSE = 5

# ══════════════════════════════════════════════════════════
#  ДИАПАЗОНЫ
# ══════════════════════════════════════════════════════════
RANGE_1_START = 980000
RANGE_1_END   = 981000
RANGE_2_START = 24000
RANGE_2_END   = 37148
INN_LENGTH = 10

POPULAR_DATES = [
    (9, 1), (1, 1), (6, 1), (5, 9),
    (3, 8), (12, 31), (1, 15), (8, 24),
]

# ══════════════════════════════════════════════════════════
#  ГЕНЕРАЦИЯ РНОКПП
# ══════════════════════════════════════════════════════════
REALISTIC_SEQ = True
SEQ_MAX = 800
GENDER_FILTER = "male"
ONLY_ODD_LAST_DIGIT = True

# ══════════════════════════════════════════════════════════
#  ФОКУСНЫЙ ДЕНЬ
# ══════════════════════════════════════════════════════════
FOCUS_DAY = 35026

# ══════════════════════════════════════════════════════════
#  SEED EXPANSION
# ══════════════════════════════════════════════════════════
SEED_NUM_RADIUS = 50
SEED_DAY_RADIUS = 2
SEED_MAX_TASKS = 5000

# ══════════════════════════════════════════════════════════
#  ПАРАЛЛЕЛИЗМ (ускорено для per_person)
# ══════════════════════════════════════════════════════════
CONCURRENCY = 20           # было 10 → 20
REQUEST_DELAY = 0.4        # было 1.0 → 0.4

# ══════════════════════════════════════════════════════════
#  RETRY
# ══════════════════════════════════════════════════════════
RETRY_ATTEMPTS = 3
RETRY_DELAY = 3.0
BACKOFF_508 = 30.0

# ══════════════════════════════════════════════════════════
#  ФАЙЛЫ
# ══════════════════════════════════════════════════════════
RESULTS_DIR  = "results"
RESULTS_FILE = os.path.join(RESULTS_DIR, "results.csv")
FOUND_FILE   = os.path.join(RESULTS_DIR, "found.csv")
LOG_FILE     = os.path.join(RESULTS_DIR, "scraper.log")
STATS_FILE   = os.path.join(RESULTS_DIR, "stats.json")
PROXIES_FILE = "proxies.txt"

# ══════════════════════════════════════════════════════════
#  САЙТ
# ══════════════════════════════════════════════════════════
BASE_URL = "https://ua.gov.edbo.info/"

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
]

BASE_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "uk-UA,uk;q=0.9,en;q=0.8",
    "Connection": "keep-alive",
}

REQUEST_TIMEOUT = 15