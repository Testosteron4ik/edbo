# run_dashboard.py
import sys

# Принудительно UTF-8 для Windows
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

from dashboard.app import create_app

if __name__ == "__main__":
    app = create_app()
    print("Dashboard запущен: http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)